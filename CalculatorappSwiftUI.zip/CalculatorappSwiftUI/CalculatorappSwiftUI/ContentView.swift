//
//  ContentView.swift
//  CalculatorappSwiftUI
//
//  Created by Anthony Codes on 14/11/2019.
//  Copyright © 2019 AnthonyDesignCodes. All rights reserved.
//

import SwiftUI

struct CalculatorButton: Identifiable, Hashable {
    let id = UUID()
    let title: String
    var color: Color = .darkGray
}

extension Color {
    static let lightGray = Color(red: 0.6, green: 0.6, blue: 0.6)
    static let darkGray = Color(red: 0.2, green: 0.2, blue: 0.2)
}

struct ContentView: View {
    
    let buttons: [[CalculatorButton]] = [
        [.init(title: "AC", color: .lightGray),
         .init(title: "+/-", color: .lightGray),
         .init(title: "%", color: .lightGray),
         .init(title: "÷", color: Color.orange)
        ],
        [.init(title: "7", color: .lightGray),
         .init(title: "8", color: .lightGray),
         .init(title: "9", color: .lightGray),
         .init(title: "x", color: Color.orange)
        ],
        [.init(title: "4", color: .lightGray),
         .init(title: "5", color: .lightGray),
         .init(title: "6", color: .lightGray),
         .init(title: "-", color: Color.orange)
        ],
        [.init(title: "1", color: .lightGray),
         .init(title: "2", color: .lightGray),
         .init(title: "3", color: .lightGray),
         .init(title: "+", color: Color.orange)
        ],
        [.init(title: "0", color: .lightGray),
         .init(title: ".", color: .lightGray),
         .init(title: "=", color: Color.orange)
        ]
    ]
    let spacing : CGFloat = 10
    
    var body: some View {
        ZStack{
            Color.black
                .edgesIgnoringSafeArea(.all)
             GeometryReader { geometry in
                       VStack (spacing: self.spacing) {
                           Spacer()
                           ForEach(self.buttons, id: \.self) { row in
                               CalculatorButtonRow(screenWidth: geometry.size.width, spacing: self.spacing, buttons: row)
                    }
                }
            }
        }
    }
}
struct CalculatorButtonRow: View {
    let screenWidth: CGFloat
    let spacing: CGFloat
    let buttons: [CalculatorButton]
    
    func getButtonWidth(title: String) -> CGFloat {
         return title != "0" ?
               (self.screenWidth - self.spacing * 5) / 4 :
               (self.screenWidth - self.spacing * 5) / 4 * 2 + self.spacing
    }
    var body: some View {
        HStack (spacing: self.spacing) {
            ForEach(self.buttons) { button in
                Text(button.title)
                    .font(.system(size: 28))
                    .foregroundColor(.white)
                    .frame(width: self.getButtonWidth(title: button.title),
                           height: (self.screenWidth - self.spacing * 5) / 4)
                    .background(button.color)
                    .cornerRadius(100)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
